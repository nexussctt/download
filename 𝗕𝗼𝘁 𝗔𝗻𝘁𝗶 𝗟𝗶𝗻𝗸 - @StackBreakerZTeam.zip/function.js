const {
    default: makeWASocket,
    useMultiFileAuthState,
    DisconnectReason
} = require('@whiskeysockets/baileys')
const qrcode = require('qrcode-terminal')
const { Boom } = require('@hapi/boom')

const groupLinkRegex = /chat\.whatsapp\.com\/\S+/gi

//list domain yang otomatis dihapus
const bannedDomains = [
    'xnxx.com', 'pornhub.com', 'xvideos.com', 'youjizz.com',
    'redtube.com', 'hentaihaven.xxx', 'jav.guru',
    '18hub.com', 'rule34.xxx', 'tubegalore.com'
]
const domainRegex = new RegExp(
    bannedDomains.map(domain => `(?:https?:\\/\\/)?(?:www\\.)?${domain.replace('.', '\\.')}`).join('|'),
    'gi'
)

//konfigurasi sistem peringatan
const maxLimit = 3
let userViolations = {}

//whitelist (user yang tidak akan dikenai sanksi)
const whitelist = [
    '6283139204289@s.whatsapp.net'
]

//gambar respon custom
const fixedImageUrl = 'https://i.pinimg.com/736x/11/47/ac/1147ac8e2343905cb93a8b0ba8e85428.jpg'

async function startBot() {
    const { state, saveCreds } = await useMultiFileAuthState('authinfo')
    const sock = makeWASocket({ auth: state })

    sock.ev.on('creds.update', saveCreds)

    sock.ev.on('connection.update', async (update) => {
        const { connection, lastDisconnect, qr } = update

        if (qr) {
            console.log('Scan QR ini untuk login:\n')
            qrcode.generate(qr, { small: true })
        }

        if (connection === 'close') {
            const shouldReconnect = (lastDisconnect?.error instanceof Boom) &&
                lastDisconnect.error.output.statusCode !== DisconnectReason.loggedOut

            console.log('koneksi terputus, reconnect:', shouldReconnect)
            if (shouldReconnect) startBot()
        }

        if (connection === 'open') {
            console.log('bot berhasil terhubung ke WhatsApp')
        }
    })

    sock.ev.on('messages.upsert', async ({ messages, type }) => {
        if (type !== 'notify') return
        const msg = messages[0]
        if (!msg.message || !msg.key.remoteJid.endsWith('@g.us')) return

        const sender = msg.key.participant || msg.key.remoteJid
        const isFromMe = msg.key.fromMe
        const jid = msg.key.remoteJid
        const text = msg.message.conversation || msg.message.extendedTextMessage?.text || ''

        if (isFromMe || whitelist.includes(sender)) return

        const foundGroupLink = text.match(groupLinkRegex)
        const foundBadDomain = text.match(domainRegex)

        if (foundGroupLink || foundBadDomain) {
            userViolations[sender] = (userViolations[sender] || 0) + 1
            const pelanggaranKe = userViolations[sender]

            try {
                await sock.sendMessage(jid, {
                    delete: {
                        remoteJid: jid,
                        fromMe: false,
                        id: msg.key.id,
                        participant: sender
                    }
                })
            } catch (e) {
                console.log("gagal menghapus pesan:", e)
            }

//pesan peringatan
            let caption = ''
            if (foundGroupLink && !foundBadDomain) {
                caption = `@${sender.split('@')[0]} mengirim link grup WhatsApp, Pelanggaran ke ${pelanggaranKe}/${maxLimit}x`
            } else if (foundBadDomain && !foundGroupLink) {
                caption = `@${sender.split('@')[0]} mengirim link website 18+, Pelanggaran ke ${pelanggaranKe}/${maxLimit}x`
            } else {
                caption = `@${sender.split('@')[0]} mengirim link grup dan link website 18+ sekaligus, Pelanggaran ke ${pelanggaranKe}/${maxLimit}x`
            }

            await sock.sendMessage(jid, {
                image: { url: fixedImageUrl },
                caption,
                mentions: [sender]
            })

            if (pelanggaranKe >= maxLimit) {
                try {
                    await sock.groupParticipantsUpdate(jid, [sender], 'remove')
                    await sock.sendMessage(jid, {
                        image: { url: fixedImageUrl },
                        caption: `@${sender.split('@')[0]} dikeluarkan karena melebihi batas pelanggaran (${maxLimit})`,
                        mentions: [sender]
                    })
                    delete userViolations[sender]
                } catch (e) {
                    console.log("gagal mengeluarkan:", e)
                }
            }
        }
    })
}

startBot()